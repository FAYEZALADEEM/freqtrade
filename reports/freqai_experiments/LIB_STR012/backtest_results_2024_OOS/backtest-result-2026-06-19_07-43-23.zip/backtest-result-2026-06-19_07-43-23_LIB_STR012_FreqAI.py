#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FreqAI version of LIB_STR012 (adapted, not modifying original)

Core logic:
- EMA trend
- Bollinger Bands (20,2) position
- Score based entry

FreqAI strict rules followed:
- % features only
- No volume
- Targets only in set_freqai_targets
- No shift(-n) in entry/exit
- enter/exit tags
- identifier via override
"""

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta
import numpy as np


class LIB_STR012_FreqAI(IStrategy):
    timeframe = '15m'
    can_short = False

    minimal_roi = {"0": 0.01}
    stoploss = -0.01

    fast_len = 21
    slow_len = 55
    bb_len = 20
    bb_mult = 2.0
    min_bars_between = 5

    startup_candle_count = 80
    process_only_new_candles = True
    use_exit_signal = True

    def feature_engineering_expand_all(
        self, dataframe: DataFrame, period: int, metadata: dict, **kwargs
    ) -> DataFrame:
        df = dataframe

        df["%-ema_fast"] = ta.EMA(df["close"], timeperiod=self.fast_len)
        df["%-ema_slow"] = ta.EMA(df["close"], timeperiod=self.slow_len)
        df["%-ema_diff"] = (df["%-ema_fast"] - df["%-ema_slow"]) / df["close"]

        df["%-trend_long"] = (df["%-ema_fast"] > df["%-ema_slow"]).astype(int)
        df["%-trend_short"] = (df["%-ema_fast"] < df["%-ema_slow"]).astype(int)

        # BB
        df["%-bb_basis"] = ta.SMA(df["close"], timeperiod=self.bb_len)
        df["%-bb_std"] = ta.STDDEV(df["close"], timeperiod=self.bb_len)
        df["%-bb_upper"] = df["%-bb_basis"] + self.bb_mult * df["%-bb_std"]
        df["%-bb_lower"] = df["%-bb_basis"] - self.bb_mult * df["%-bb_std"]

        df["%-bb_pos"] = (df["close"] - df["%-bb_lower"]) / (df["%-bb_upper"] - df["%-bb_lower"] + 1e-9)
        df["%-bb_long"] = ((df["close"] > df["%-bb_basis"]) & (df["close"] < df["%-bb_upper"])).astype(int)
        df["%-bb_short"] = ((df["close"] < df["%-bb_basis"]) & (df["close"] > df["%-bb_lower"])).astype(int)

        df["%-close_to_bb_upper"] = (df["%-bb_upper"] - df["close"]) / df["close"]
        df["%-close_to_bb_lower"] = (df["close"] - df["%-bb_lower"]) / df["close"]

        return df

    def feature_engineering_expand_basic(
        self, dataframe: DataFrame, metadata: dict, **kwargs
    ) -> DataFrame:
        df = dataframe
        df["%-pct_change"] = df["close"].pct_change()
        df["%-raw_price"] = df["close"]
        return df

    def feature_engineering_standard(
        self, dataframe: DataFrame, metadata: dict, **kwargs
    ) -> DataFrame:
        df = dataframe
        df["%-hour_of_day"] = (df["date"].dt.hour + 1) / 25
        df["%-day_of_week"] = (df["date"].dt.dayofweek + 1) / 7
        return df

    def set_freqai_targets(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        label_period = self.freqai_info["feature_parameters"]["label_period_candles"]
        dataframe["&-s_close"] = (
            dataframe["close"]
            .shift(-label_period)
            .rolling(label_period)
            .mean()
            / dataframe["close"]
            - 1
        )
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = self.freqai.start(dataframe, metadata, self)

        if "%-trend_long" in dataframe.columns:
            dataframe["fai_confluence_long"] = (
                (dataframe["%-trend_long"] == 1).astype(int) +
                (dataframe["%-bb_long"] == 1).astype(int)
            )
        else:
            dataframe["fai_confluence_long"] = 0

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe

        long_cond = (
            (df.get("do_predict", 0) == 1) &
            (df["&-s_close"] > 0.0008) &
            (df.get("fai_confluence_long", 0) >= 1)
        )

        df.loc[long_cond, ["enter_long", "enter_tag"]] = (1, "fai012_long_ai")

        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe
        exit_cond = (
            (df.get("do_predict", 0) == 1) &
            (df["&-s_close"] < -0.0004)
        )
        df.loc[exit_cond, ["exit_long", "exit_tag"]] = (1, "fai012_ai_exit")
        return df
