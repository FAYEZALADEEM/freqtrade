#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FreqAI version of LIB_STR013 (adapted, not modifying original)

Core logic from original:
- EMA fast/slow trend
- Structure high/low
- Bullish/bearish engulf
- Demand/supply zone touches

FreqAI adaptations (strict rules):
- All features start with '%'
- No volume features
- Target defined only in set_freqai_targets
- No shift(-n) in entry/exit signals
- enter_tag and exit_tag on every signal
- Uses LightGBMRegressor via freqai.start
- identifier will be set via override: e.g. "lib_str013_fai_v1"
"""

from freqtrade.strategy import IStrategy
from LIB_STR013 import LIB_STR013
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
from functools import reduce


class LIB_STR013_FreqAI(IStrategy):
    """
    FreqAI adapted version for LIB_STR013.
    AI predicts future return. Entry based on prediction + technical confluence.
    Exit primarily by model prediction + ROI/SL.
    """

    timeframe = '15m'
    can_short = False

    minimal_roi = {"0": 0.01}
    stoploss = -0.01

    # Original params
    fast_len = 21
    slow_len = 55
    structure_lookback = 20
    zone_lookback = 30
    min_bars_between = 5

    # FreqAI related
    startup_candle_count = 100
    process_only_new_candles = True
    use_exit_signal = True

    # For FreqAI target (will be overridden in config via override)
    # label_period_candles will come from freqai config override

    def feature_engineering_expand_all(
        self, dataframe: DataFrame, period: int, metadata: dict, **kwargs
    ) -> DataFrame:
        """
        Expand core features. All start with '%'
        """
        df = dataframe

        # EMA trend (original fast/slow)
        df["%-ema_fast"] = ta.EMA(df["close"], timeperiod=self.fast_len)
        df["%-ema_slow"] = ta.EMA(df["close"], timeperiod=self.slow_len)
        df["%-ema_diff"] = (df["%-ema_fast"] - df["%-ema_slow"]) / df["close"]

        # Structure
        df["%-struct_high"] = df["high"].rolling(self.structure_lookback).max().shift(1)
        df["%-struct_low"] = df["low"].rolling(self.structure_lookback).min().shift(1)
        df["above_struct"] = (df["close"] > df["%-struct_high"]).astype(int)
        df["%-below_struct"] = (df["close"] < df["%-struct_low"]).astype(int)

        # Engulf (as binary features)
        df["bullish_engulf"] = (
            (df["close"] > df["open"])
            & (df["close"].shift(1) < df["open"].shift(1))
            & (df["close"] >= df["open"].shift(1))
            & (df["open"] <= df["close"].shift(1))
        ).astype(int)

        df["%-bearish_engulf"] = (
            (df["close"] < df["open"])
            & (df["close"].shift(1) > df["open"].shift(1))
            & (df["close"] <= df["open"].shift(1))
            & (df["open"] >= df["close"].shift(1))
        ).astype(int)

        # Zones (rolling min/max as features)
        df["%-demand_zone"] = df["low"].rolling(self.zone_lookback).min()
        df["%-supply_zone"] = df["high"].rolling(self.zone_lookback).max()
        df["%-demand_touch"] = (
            (df["low"] <= df["%-demand_zone"] * 1.002) & (df["close"] > df["open"])
        ).astype(int)
        df["%-supply_touch"] = (
            (df["high"] >= df["%-supply_zone"] * 0.998) & (df["close"] < df["open"])
        ).astype(int)

        # Trend binary
        df["trend_long"] = (df["%-ema_fast"] > df["%-ema_slow"]).astype(int)
        df["%-trend_short"] = (df["%-ema_fast"] < df["%-ema_slow"]).astype(int)

        # Additional useful % features (no volume)
        df["%-close_to_demand"] = (df["close"] - df["%-demand_zone"]) / df["close"]
        df["%-close_to_supply"] = (df["%-supply_zone"] - df["close"]) / df["close"]

        return df

    def feature_engineering_expand_basic(
        self, dataframe: DataFrame, metadata: dict, **kwargs
    ) -> DataFrame:
        """
        Basic features not expanded by period.
        """
        df = dataframe
        df["%-pct_change"] = df["close"].pct_change()
        df["%-raw_price"] = df["close"]
        return df

    def feature_engineering_standard(
        self, dataframe: DataFrame, metadata: dict, **kwargs
    ) -> DataFrame:
        df = dataframe
        # Time features
        df["%-hour_of_day"] = (df["date"].dt.hour + 1) / 25
        df["%-day_of_week"] = (df["date"].dt.dayofweek + 1) / 7
        return df

    def set_freqai_targets(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        """
        Target only here. Future mean return.
        label_period_candles from freqai config.
        """
        label_period = self.freqai_info["feature_parameters"]["label_period_candles"]
        dataframe["&-s_close"] = (
            dataframe["close"]
            .shift(-label_period)
            .rolling(label_period)
            .mean()
            / dataframe["close"]
            - 1
        )
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # FreqAI predictions (do_predict, &-s_close), then original indicators/score
        dataframe = self.freqai.start(dataframe, metadata, self)
        dataframe = LIB_STR013.populate_indicators(self, dataframe, metadata)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe
        # Original entry: score threshold. AI is a SOFT filter (blocks only clear-down predictions).
        base_long = (df["long_score"] >= 1) & (df["volume"] > 0)
        ai_block = (df["do_predict"] == 1) & (df["&-s_close"] < -0.0005)
        df.loc[base_long & (~ai_block), ["enter_long", "enter_tag"]] = (1, "lib013_long")
        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe
        exit_long = (df["do_predict"] == 1) & (df["&-s_close"] < -0.001)
        df.loc[exit_long, ["exit_long", "exit_tag"]] = (1, "lib013_ai_exit")
        return df
