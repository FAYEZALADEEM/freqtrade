#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FreqAI version of LIB_STR045 - Robust simplified version

Focus:
- Reliable FreqAI integration
- No volume
- Proper % / & naming
- enter/exit tags
- Technical confluence after FreqAI
"""

from freqtrade.strategy import IStrategy
from LIB_STR045 import LIB_STR045
from pandas import DataFrame
import talib.abstract as ta
from technical import qtpylib


class LIB_STR045_FreqAI(IStrategy):
    timeframe = "15m"
    can_short = False

    minimal_roi = {"0": 0.01}
    stoploss = -0.01
    use_exit_signal = True
    startup_candle_count = 80

    # Original parameters
    fast_len = 21
    slow_len = 55
    structure_lookback = 20
    zone_lookback = 30

    def feature_engineering_expand_all(
        self, dataframe: DataFrame, period: int, metadata: dict, **kwargs
    ) -> DataFrame:
        df = dataframe

        # Core trend
        df["%-ema_fast"] = ta.EMA(df["close"], timeperiod=period)
        df["%-ema_slow"] = ta.EMA(df["close"], timeperiod=period * 2)
        df["%-ema_diff"] = (df["%-ema_fast"] - df["%-ema_slow"]) / df["close"]

        # Structure
        df["%-struct_high"] = df["high"].rolling(period).max().shift(1)
        df["%-struct_low"] = df["low"].rolling(period).min().shift(1)
        df["%-above_struct"] = (df["close"] > df["%-struct_high"]).astype(int)

        # Engulf pattern
        df["%-bullish_engulf"] = (
            (df["close"] > df["open"])
            & (df["close"].shift(1) < df["open"].shift(1))
            & (df["close"] >= df["open"].shift(1))
        ).astype(int)

        # Additional useful features
        df["%-rsi"] = ta.RSI(df["close"], timeperiod=period)
        df["%-adx"] = ta.ADX(df, timeperiod=period)

        return df

    def feature_engineering_standard(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        df = dataframe
        df["%-hour_of_day"] = (df["date"].dt.hour + 1) / 25
        return df

    def set_freqai_targets(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        label_period = self.freqai_info["feature_parameters"]["label_period_candles"]
        dataframe["&-s_close"] = (
            dataframe["close"]
            .shift(-label_period)
            .rolling(label_period)
            .mean()
            / dataframe["close"]
            - 1
        )
        return dataframe

    fast_len = 21
    slow_len = 55
    structure_lookback = 20
    zone_lookback = 30
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # FreqAI predictions (do_predict, &-s_close), then original indicators/score
        dataframe = self.freqai.start(dataframe, metadata, self)
        dataframe = LIB_STR045.populate_indicators(self, dataframe, metadata)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe
        # Original entry: score threshold. AI is a SOFT filter (blocks only clear-down predictions).
        base_long = (df["long_score"] >= 2) & (df["volume"] > 0)
        ai_block = (df["do_predict"] == 1) & (df["&-s_close"] < -0.0005)
        df.loc[base_long & (~ai_block), ["enter_long", "enter_tag"]] = (1, "lib045_long")
        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe
        exit_long = (df["do_predict"] == 1) & (df["&-s_close"] < -0.001)
        df.loc[exit_long, ["exit_long", "exit_tag"]] = (1, "lib045_ai_exit")
        return df
